from setuptools import setup

setup(
    name="Calculos basicos matematicos",
    version="1.0",
    description="Paquete para calculos basicos",
    author="El menda",
    author_mail="caca@caca.com",
    url="",
    packages=["calculosMatematicos", "calculosMatematicos.calculosBasicos"]

)